<?php

$page=$_GET['page'];

switch ($page) {
    case "home":
        $title="Главная страница сайта";
        $text="Добро пожаловать на наш сайт. Здесь вы найдете много интересного";
        break;
    case "news":
        $title="Новости";
        $text="Свежие новости спорта";
        break;
    case "video":
        $title="Видео";
        $text="Видео с прошедших соревнований";
        break;

    default:
        $title="Страница не найдена";
        $text="Вернитесь назад";
        break;
}
?>	
<html>
	<head>
	<meta charset="utf-8">
	<title><?php echo $title ?></title>
	</head>
	<body>
            <a href="method(get).php?page=home">Главная</a>
            <a href="method(get).php?page=news">Новости</a>
            <a href="method(get).php?page=video">Видео</a>
            <h1><?php echo $title ?></h1>
            <p><?php echo $text ?></p>
	
		
	</body>
</html>