<?php
   $connection = mysql_connect("localhost", "mydb_user","123");//устанавливаем соединение
    $db = mysql_select_db("NewBD");//выбираем базу
   
    if(!$connection||!$db){//проверяем на ошибку
        exit(mysql_error());//прекращаем работу скрипта и высвечиваем ошибку
    }
   
