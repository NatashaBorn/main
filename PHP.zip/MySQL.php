<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>Название страницы</title>
	</head>
	<body>
           <a href="addDB.php">Добавить новость</a>
                
<?php

    $connection = mysql_connect("localhost", "root","");
    $db = mysql_select_db("Articles");
    
    if(!$connection||!$db){
        exit(mysql_error());
    }

    $result=mysql_query("SELECT*FROM news ");
    
    mysql_close();
    $row=mysql_fetch_array($result);
    echo $row['title'];
    
    /*while ($row = mysql_fetch_array($result)) {?>        
    <h1><?php echo $row['title'];?></h1>
    <p><?php echo $row['text'];?></p>
    <p>Дата публикации: <?php echo $row['date'];?> / <?php echo $row['time'];?></p>
    <p>Автор новости: <?php echo $row['author'];?></p>
    <hr/>	
    <?php }*/?>
	</body>
</html>
