
<html>
	<head>
	<meta charset="utf-8">
	<title>Название страницы</title>
	</head>
	<body>
            <form method="GET" action="method(post).php">
                <input type="text" name="login"/><br>    
                <input type="password" name="pswd"/><br>	  
                <input type="submit" name="send" value="Войти"/>    
            </form>
<?php
    
?>		
		
	</body>
</html>


