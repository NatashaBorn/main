<meta charset="utf-8">
<?php
$a=1;
function Test_g(){
global $a; $a = $a*2;
echo 'в результате работы
функции $a=',$a;}
echo 'вне функции $a=',$a,', ';
Test_g();echo "<br>";
echo 'вне функции $a=',$a,', ';
Test_g();


    