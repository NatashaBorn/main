<?php
    if(isset($_POST)){
        $password1=$_POST["pass1"];
        $password2=$_POST["pass2"];
        
        if($password1==$password2)
            echo "Good!!!";
        else 
            echo "lol!!!";
        
    };
    ?>